package com.gamingroom;

public class Entity {

// private variables
private long id;
private String name;

// default constructor
private Entity() {
}

	// custom constructor using id and name
	public Entity(long id, String name) {
		//calling the instructor
		this();
		this.name = name;
		this.id = id;
		
	}

	public long getId() { // call for id
		return id;
	}

	public String getName() { //call for name
		return name;
	}

	// string return
	public String toString() {
		return "Entity [id=" + id + ", name=" + name + "]";
	}
}