package com.gamingroom;

import java.util.ArrayList;
import java.util.List;

/**
 * A singleton service for the game engine
 * 
 * @author coce@snhu.edu
 */
public class GameService {

	/**
	 * A list of the active games
	 */
	private static List<Game> games = new ArrayList<Game>();

	/*
	 * Holds the next game identifier
	 */
	private static long nextGameId = 1;

	// Use of a singleton is best used in cases like this where you have to logging, or a class that needs to be used
	// over and over again and that class will be accessed on different parts of the program as a shared resource.
	
	// using a private constructor the code creates a singleton local instance of the class since only one will exist
	private static GameService instance =  new GameService();
	
	
	// private constructor normally used with singleton so no additional instances of GameService are made outside this class
	private void GameService() {
	}
	
	/**
	 * Construct a new game instance
	 * 
	 * @param name the unique name of the game
	 * @return the game instance (new or existing)
	 */
	
	public static GameService getInstance(){
		return instance;
	}
	
	
	public Game addGame(String name) {

		// a local game instance
		Game game = null;
		
		//Game gameInstance = gamesIterator.next();
		
		// checks to see if Game already exists and if so returns it without change
		for (Game currentGame : games) {
			if (currentGame.getName().equals(name)){
				return currentGame;
			}
		}
		
		// uses iterator pattern to add objects to games
		
		// if statement that checks to see if game is not found, if so assigns game as a new game with the next id
		// and the current name and adds it to the games list (method best used for single thread)
		if (game == null) {
			game = new Game(nextGameId++, name);
			games.add(game);
		}
		

		// return the new/existing game instance to the caller
		return game;
	}

	/**
	 * Returns the game instance at the specified index.
	 * <p>
	 * Scope is package/local for testing purposes.
	 * </p>
	 * @param index index position in the list to return
	 * @return requested game instance
	 */
	Game getGame(int index) {
		return games.get(index);
	}
	
	/**
	 * Returns the game instance with the specified id.
	 * 
	 * @param id unique identifier of game to search for
	 * @return requested game instance
	 */
	public Game getGame(long id) {

		// a local game instance
		Game game = null;

		//checks for game with the same id if found assigns game with currentGame otherwise return the game instance
		for (Game currentGame : games) {
			if (currentGame.getId() == id) {
				game = currentGame;
			}
		}

		return game;
	}

	/**
	 * Returns the game instance with the specified name.
	 * 
	 * @param name unique name of game to search for
	 * @return requested game instance
	 */
	public Game getGame(String name) {

		// a local game instance
		Game game = null;

		//checks for game with the same name and if found assigns game with currentGame otherwise return game instance
		for (Game currentGame : games) {
			if (currentGame.getName().equals(name)) {
				game = currentGame;
			}
		}

		return game;
	}

	/**
	 * Returns the number of games currently active
	 * 
	 * @return the number of games currently active
	 */
	public int getGameCount() {
		return games.size();
	}
}
